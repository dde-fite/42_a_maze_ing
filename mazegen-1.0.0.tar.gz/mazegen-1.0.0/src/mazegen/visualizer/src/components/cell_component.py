from typing import cast
from pathlib import Path
from ..core.components import BaseComponent, SpriteRenderer


class CellComponent(BaseComponent):
    def on_init(self) -> None:
        from ..nodes.cell_node import CellNode
        self.__owner_cell = cast(CellNode, self.owner)
        self.__sprite_renderer = self.__owner_cell[SpriteRenderer]
        self.__walls_folder = Path(__file__).parent.parent / "sprites" / \
            "walls"
        self.__cell = self.__owner_cell.cell
        self.__is_fixed: bool = False
        if self.__cell["fixed"]:
            self.__is_fixed = True
            self.__sprite_renderer.set_file_path(self.__walls_folder.joinpath
                                                 ("fixed.png"))
            return
        self.__state = self.__cell["state"]
        self.__alt: str | None = None

    def on_update(self) -> None:
        if self.__is_fixed:
            return
        state = self.__cell["state"]
        from ..nodes.maze_root import MazeRoot
        maze_root: MazeRoot = cast(MazeRoot, self.owner.parent_node)
        if maze_root:
            alt = maze_root.alt
        if self.__state != state and self.__alt != alt:
            return
        if state == 0b0000:
            self.__sprite_renderer.set_file_path(None)
            return
        name: str = ""
        if state & 0b0001:
            name = "-".join([name, "up"])
        if state & 0b0010:
            name = "-".join([name, "right"])
        if state & 0b0100:
            name = "-".join([name, "down"])
        if state & 0b1000:
            name = "-".join([name, "left"])
        name = name.removeprefix("-")
        name += ".png"
        if alt:
            name = f"{alt}_" + name
        self.__sprite_renderer.set_file_path(self.__walls_folder.joinpath
                                             (name))

    def on_destroy(self) -> None:
        pass
